//
// Created by kangjj on 2019/8/13.
//

#ifndef INC_3_2_4_PLAYER_BASECHANNEL_H
#define INC_3_2_4_PLAYER_BASECHANNEL_H

#include <libavcodec/avcodec.h>
#include <libavutil/frame.h>
#include "safe_queue.h"

class BaseChannel{
public:
    BaseChannel(int id):id(id){
        packets.setReleaseCallback(releaseAVPacket);
        frames.setReleaseCallback(releaseAVFrame);
    }
    //虚函数是指一个类中你希望重载的成员函数，当你用一个基类指针或引用指向一个继承对象的时候，
//    调用一个虚函数时，实际调用的是继承类的版本。
    virtual ~BaseChannel(){
        packets.clear();
        frames.clear();
    }

    void releaseAVPacket(AVPacket **packet){//这里的T表示AVPacket* 所以需要传入AVPacket**
        if(packet){
            av_packet_free(packet);
            *packet = 0;
        }
    }

    void releaseAVFrame(AVFrame ** frame){
        if(frame){
            av_frame_free(frame);
            *frame = 0;
        }
    }
    virtual void start();
    virtual void stop();

    int id;
    SafeQueue<AVPacket *> packets;
    SafeQueue<AVFrame *> frames;
};

#endif //INC_3_2_4_PLAYER_BASECHANNEL_H
