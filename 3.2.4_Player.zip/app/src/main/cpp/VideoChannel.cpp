//
// Created by kangjj on 2019/8/13.
//

#include "VideoChannel.h"
VideoChannel::VideoChannel(int id):BaseChannel(id) {}

VideoChannel::~VideoChannel() {}

void VideoChannel::start() {
    //设置队列状态
}

void VideoChannel::stop() {

}