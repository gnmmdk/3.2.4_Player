//
// Created by kangjj on 2019/8/13.
//

#ifndef INC_3_2_4_PLAYER_MACRO_H
#define INC_3_2_4_PLAYER_MACRO_H

#include <android/log.h>

//定义释放的宏函数
#define DELETE(object) if(object){delete object;object = 0;}

// 定义日志打印宏函数
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR,"NEFFMPEG",__VA_ARGS__)

//标记线程模式
#define THREAD_MAIN 1
#define THREAD_CHILD 2

//错误返回码
#define ERROR_RET0 = 100;
#define ERROR_RET1 = -101;
#define ERROR_RET2 = -102;
#define ERROR_RET3 = -103;
#define ERROR_RET4 = -104;
#define ERROR_RET5 = -105;
#define ERROR_RET6 = -106;
#define ERROR_RET7 = -107;
#define ERROR_RET8 = -108;
#define ERROR_RET9 = -109;

#endif //INC_3_2_4_PLAYER_MACRO_H
