//
// Created by kangjj on 2019/8/13.
//

#ifndef INC_3_2_4_PLAYER_HAVACALLHEPLER_H
#define INC_3_2_4_PLAYER_HAVACALLHEPLER_H

#include <jni.h>
#include "macro.h"

class JavaCallHelper {

public:
    JavaCallHelper(JavaVM * javaVM_,JNIEnv *env_,jobject instance_);
    ~JavaCallHelper();
    void onPrepared(int threadMode);

    void sendErrorJavaCallHelper(int ret, char *msg);

private:
    JavaVM *javaVM;
    JNIEnv *env;
    jobject instance;
    jmethodID jmd_prepared;
};


#endif //INC_3_2_4_PLAYER_HAVACALLHEPLER_H
