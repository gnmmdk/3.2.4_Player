//
// Created by kangjj on 2019/8/13.
//
#include "NEFFmpeg.h"

NEFFmpeg::NEFFmpeg(JavaCallHelper *javaCallHelper, char *dataSource) {
    this->javaCallHelper = javaCallHelper;
    //这里dataSource是从Java传过来的字符串，通过jni接口转变成了c++字符串。
//在jni方法中被释放掉了，导致dataSource变成悬空指针的问题（指向一块已经释放了的内存）
//    this->dataSource = dataSource;?

//内存拷贝，自己管理它的内存，strlen获取字符串长度，strcpy:拷贝字符串
//java:"hello" c字符串以\0 结尾:"hello\0"
    this->dataSource = new char[strlen(dataSource) + 1];
    strcpy(this->dataSource, dataSource);
}

NEFFmpeg::~NEFFmpeg() {
    DELETE(dataSource);
    DELETE(javaCallHelper);
}

void *task_prepare(void *args) {
    //打开输入 这里的args对应到pthread_create(&pid_prepare,0,task_prepare,this);的第四个参数（this）
    NEFFmpeg *ffmpeg = static_cast<NEFFmpeg *>(args);
    ffmpeg->_prepare();
    return 0;//一定一定一定要返回0！！！
}

void* task_start(void* args){
    NEFFmpeg * ffmpeg = static_cast<NEFFmpeg *>(args);
    ffmpeg->_start();
    return 0;
}

void NEFFmpeg::_prepare() {
    //0.5 AVFormatContext **ps
    formatContext = avformat_alloc_context();
    AVDictionary *dictionary = 0;
    av_dict_set(&dictionary, "timeout", "10000000", 0);//设置超时时间为10秒，这里的单位是微秒
    //1.打开媒体
    int ret = avformat_open_input(&formatContext, dataSource, 0, &dictionary);
    av_dict_free(&dictionary);
    if (ret) {
        LOGE("打印媒体失败：%s", av_err2str(ret));
//        javaCallHelper->sendErrorJavaCallHelper(ERROR_RET0,"dakai");
        //TODO
        return;
    }
    //2 查找媒体中的流信息
    ret = avformat_find_stream_info(formatContext, 0);
    if (ret < 0) {
        LOGE("查找媒体中的流信息失败:%s", av_err2str(ret));
        //TODO
        return;
    }
    //这里的i是后面的packet->stream_index
    for (int i = 0; i < formatContext->nb_streams; ++i) {
        //3_1 获取流媒体（音频或者视频）
        AVStream *stream = formatContext->streams[i];
        //3_2获取编解码这段流的参数
        AVCodecParameters *codecParameters = stream->codecpar;
        //3_3 通过参数中的id（编解码的方式），来查找当前流的解码器
        AVCodec *codec = avcodec_find_decoder(codecParameters->codec_id);
        if (!codec) {
            LOGE("查找当前流的解码器失败");
            //TODO
            return;
        }
        //4 创建解码器上下文
        AVCodecContext *codecContext = avcodec_alloc_context3(codec);
        // 5 设置解码器上下文参数
        ret = avcodec_parameters_to_context(codecContext, codecParameters);
        if (ret < 0) {
            LOGE("设置解码器上下文的参数失败:%s", av_err2str(ret));
            //TODO
            return;
        }
        //6 打开解码器
        ret = avcodec_open2(codecContext, codec, 0);
        if (ret) {
            LOGE("打开解码器失败:%s", av_err2str(ret));
            return;
        }
        //判断流类型（音频还是视频？）
        if (codecParameters->codec_type == AVMEDIA_TYPE_AUDIO) {
            //音频
            audioChannel = new AudioChannel(i);
        } else if (codecParameters->codec_type == AVMEDIA_TYPE_VIDEO) {
            //视频
            videoChannel = new VideoChannel(i);
        }
    }//end for
    if (!audioChannel && !videoChannel) {
        LOGE("没有音视频");
        //TODO
        return;
    }
    //准备好了，反射通知java
    if(javaCallHelper){
        javaCallHelper->onPrepared(THREAD_CHILD);
    }

}

/*
 * 播放准备
 */
void NEFFmpeg::prepare() {
    //pthread_create :创建子线程
    //int pthread_create(pthread_t* __pthread_ptr, pthread_attr_t const* __attr, void* (*__start_routine)(void*), void*);
    pthread_create(&pid_prepare, 0, task_prepare, this);
}

void NEFFmpeg::start() {
    isPlaying = 1;
    pthread_create(&pid_start,0,task_start,this);
}
/**
 * 真正执行解码播放
 */
void NEFFmpeg::_start() {
    while(isPlaying){
        //7_1 给AVPacket分配内存空间
        AVPacket *packet = av_packet_alloc();
        //7_2 从媒体中读取音/视频报
        int ret = av_read_frame(formatContext,packet);
        if(!ret){
            //ret为0 表示成功
            //要判断流类型，是视频还是音频
            if(videoChannel && packet->stream_index == videoChannel->id){
                videoChannel->packets.push(packet);
            }else if(audioChannel && packet->stream_index == audioChannel->id) {

            }
        }
    }
}
