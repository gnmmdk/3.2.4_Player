//
// Created by kangjj on 2019/8/13.
//

#include "AudioChannel.h"

AudioChannel::AudioChannel(int id) : BaseChannel(id) {}

AudioChannel::~AudioChannel() {

}

void AudioChannel::start() {
    //设置队列状态
}

void AudioChannel::stop() {

}
