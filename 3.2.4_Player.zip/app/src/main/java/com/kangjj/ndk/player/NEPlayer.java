package com.kangjj.ndk.player;

public class NEPlayer {
    static{
        System.loadLibrary("kjjPlayer");
    }
    //直播地址或媒体文件路径
    private String dataSource;


    public void setDataSource(String dataSource) {
        this.dataSource = dataSource;
    }

    public void prepare(){
        prepareNative(dataSource);
    }

    public void start(){
        startNative();
    }

    public void onPrepared(){
        if(mOnpreparedListener!=null){
            mOnpreparedListener.onPrepared();
        }
    }

    private native void startNative();

    private native void prepareNative(String dataSource);

    public void setOnPreparedListener(OnpreparedListener onpreparedListener){
        this.mOnpreparedListener = onpreparedListener;
    }

    private OnpreparedListener mOnpreparedListener;

    interface OnpreparedListener{
        void onPrepared();
    }
}
