package com.kangjj.ndk.player;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.SurfaceView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

public class MainActivity extends AppCompatActivity {
    private SurfaceView surfaceView;
    private NEPlayer player;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        surfaceView = findViewById(R.id.surfaceView);
        player = new NEPlayer();
        player.setDataSource(new File("/sdcard/","input.mp4").getAbsolutePath());
        player.setOnPreparedListener(new NEPlayer.OnpreparedListener() {
            @Override
            public void onPrepared() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(),"开始播放！", Toast.LENGTH_SHORT).show();
                    }
                });
                //播放，调用到native
                player.start();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(player!=null) {
            player.prepare();
        }
    }
}
